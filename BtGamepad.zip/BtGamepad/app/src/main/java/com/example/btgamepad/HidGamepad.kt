package com.example.btgamepad

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context

/**
 * Makes this phone appear as a Bluetooth HID gamepad.
 * Report layout (Report ID 1, 7 bytes): 16 buttons, X, Y, Z, Rz (0..255), hat switch (low nibble).
 */
@SuppressLint("MissingPermission")
class HidGamepad(private val ctx: Context, private val onStatus: (String) -> Unit) {

    private val adapter = ctx.getSystemService(BluetoothManager::class.java).adapter
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false

    private val descriptor = byteArrayOf(
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x05,             // Usage (Game Pad)
        0xA1.toByte(), 0x01,    // Collection (Application)
        0x85.toByte(), 0x01,    //   Report ID 1
        // 16 buttons
        0x05, 0x09,             //   Usage Page (Button)
        0x19, 0x01,             //   Usage Min (1)
        0x29, 0x10,             //   Usage Max (16)
        0x15, 0x00,             //   Logical Min (0)
        0x25, 0x01,             //   Logical Max (1)
        0x75, 0x01,             //   Report Size (1)
        0x95.toByte(), 0x10,    //   Report Count (16)
        0x81.toByte(), 0x02,    //   Input (Data,Var,Abs)
        // 4 axes: X, Y, Z, Rz
        0x05, 0x01,             //   Usage Page (Generic Desktop)
        0x09, 0x30,             //   Usage (X)
        0x09, 0x31,             //   Usage (Y)
        0x09, 0x32,             //   Usage (Z)
        0x09, 0x35,             //   Usage (Rz)
        0x15, 0x00,             //   Logical Min (0)
        0x26, 0xFF.toByte(), 0x00, // Logical Max (255)
        0x75, 0x08,             //   Report Size (8)
        0x95.toByte(), 0x04,    //   Report Count (4)
        0x81.toByte(), 0x02,    //   Input (Data,Var,Abs)
        // Hat switch
        0x09, 0x39,             //   Usage (Hat switch)
        0x15, 0x00,             //   Logical Min (0)
        0x25, 0x07,             //   Logical Max (7)
        0x35, 0x00,             //   Physical Min (0)
        0x46, 0x3B, 0x01,       //   Physical Max (315)
        0x65, 0x14,             //   Unit (degrees)
        0x75, 0x04,             //   Report Size (4)
        0x95.toByte(), 0x01,    //   Report Count (1)
        0x81.toByte(), 0x42,    //   Input (Data,Var,Abs,Null state)
        0x75, 0x04,             //   Report Size (4) padding
        0x95.toByte(), 0x01,    //   Report Count (1)
        0x81.toByte(), 0x03,    //   Input (Const)
        0xC0.toByte()           // End Collection
    )

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidGamepad.registered = registered
            onStatus(if (registered) "Ready. Pair from the iPad's Bluetooth settings." else "Not registered")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    onStatus("Connected to ${device.name ?: device.address}")
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host?.address == device.address) host = null
                    onStatus("Disconnected")
                }
                BluetoothProfile.STATE_CONNECTING -> onStatus("Connecting...")
            }
        }
    }

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            hid = proxy as BluetoothHidDevice
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "BT Gamepad", "Phone gamepad", "BtGamepad",
                BluetoothHidDevice.SUBCLASS2_GAMEPAD, descriptor
            )
            hid?.registerApp(sdp, null, null, ctx.mainExecutor, callback)
        }

        override fun onServiceDisconnected(profile: Int) {
            hid = null
            registered = false
            onStatus("HID service lost")
        }
    }

    fun start() {
        if (adapter == null || !adapter.isEnabled) {
            onStatus("Turn Bluetooth on first")
            return
        }
        adapter.getProfileProxy(ctx, listener, BluetoothProfile.HID_DEVICE)
    }

    fun stop() {
        hid?.unregisterApp()
        hid?.let { adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
        hid = null
    }

    fun bondedDevices(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(device: BluetoothDevice) {
        if (!registered) { onStatus("Not ready yet"); return }
        hid?.connect(device)
    }

    fun send(buttons: Int, lx: Int, ly: Int, rx: Int, ry: Int, hat: Int) {
        val h = host ?: return
        val report = byteArrayOf(
            (buttons and 0xFF).toByte(),
            ((buttons shr 8) and 0xFF).toByte(),
            lx.toByte(), ly.toByte(), rx.toByte(), ry.toByte(),
            (hat and 0x0F).toByte()
        )
        hid?.sendReport(h, 1, report)
    }
}
