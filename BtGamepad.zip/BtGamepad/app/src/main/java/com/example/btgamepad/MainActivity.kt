package com.example.btgamepad

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var pad: HidGamepad

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        pad = HidGamepad(this) { msg -> runOnUiThread { status.text = msg } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 8, 16, 8) }
        status = TextView(this).apply { setTextColor(Color.WHITE); text = "Starting..."; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val discover = Button(this).apply { text = "Pair new"; setOnClickListener { makeDiscoverable() } }
        val connect = Button(this).apply { text = "Connect"; setOnClickListener { pickPairedDevice() } }
        bar.addView(status); bar.addView(discover); bar.addView(connect)

        val view = GamepadView(this) { b, lx, ly, rx, ry, hat -> pad.send(b, lx, ly, rx, ry, hat) }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 1)
        } else pad.start()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) pad.start()
        else status.text = "Bluetooth permission is required"
    }

    private fun makeDiscoverable() {
        startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
    }

    private fun pickPairedDevice() {
        val devices = pad.bondedDevices()
        if (devices.isEmpty()) { status.text = "No paired devices. Tap 'Pair new' first."; return }
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Connect to")
            .setItems(names) { _, i -> pad.connect(devices[i]) }.show()
    }

    override fun onDestroy() { pad.stop(); super.onDestroy() }
}
