package com.example.btgamepad

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/** Touch gamepad. Calls onState(buttons, lx, ly, rx, ry, hat) whenever something changes. */
class GamepadView(
    ctx: Context,
    private val onState: (Int, Int, Int, Int, Int, Int) -> Unit
) : View(ctx) {

    companion object {
        const val A = 0; const val B = 1; const val X = 2; const val Y = 3
        const val L1 = 4; const val R1 = 5; const val L2 = 6; const val R2 = 7
        const val SELECT = 8; const val START = 9
        // Hat values: 0=N 1=NE 2=E 3=SE 4=S 5=SW 6=W 7=NW, 15=none
        const val HAT_NONE = 15
    }

    private class Btn(val bit: Int, val label: String, var cx: Float = 0f, var cy: Float = 0f,
                      var rect: RectF = RectF(), var round: Boolean = true, var r: Float = 0f)

    private val btns = listOf(
        Btn(A, "A"), Btn(B, "B"), Btn(X, "X"), Btn(Y, "Y"),
        Btn(L1, "L1", round = false), Btn(R1, "R1", round = false),
        Btn(L2, "L2", round = false), Btn(R2, "R2", round = false),
        Btn(SELECT, "SEL", round = false), Btn(START, "START", round = false)
    )

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF888888.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER }

    private var lsx = 0f; private var lsy = 0f; private var lsr = 0f   // left stick center + radius
    private var rsx = 0f; private var rsy = 0f
    private var dpx = 0f; private var dpy = 0f; private var dpr = 0f

    private var leftId = -1; private var rightId = -1
    private var lKnobX = 0f; private var lKnobY = 0f
    private var rKnobX = 0f; private var rKnobY = 0f

    private var curButtons = 0; private var curHat = HAT_NONE
    private var curLx = 128; private var curLy = 128; private var curRx = 128; private var curRy = 128
    private var lastSent: List<Int> = emptyList()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val fw = w.toFloat(); val fh = h.toFloat()
        lsr = fh * 0.2f; lsx = fw * 0.16f; lsy = fh * 0.4f
        rsr = lsr; rsx = fw * 0.72f; rsy = fh * 0.78f
        dpr = fh * 0.17f; dpx = fw * 0.16f; dpy = fh * 0.82f - dpr * 0.1f
        // ABXY diamond
        val cx = fw * 0.84f; val cy = fh * 0.4f; val o = fh * 0.15f; val br = fh * 0.095f
        place(btns[A], cx, cy + o, br); place(btns[B], cx + o, cy, br)
        place(btns[X], cx - o, cy, br); place(btns[Y], cx, cy - o, br)
        // shoulders / triggers across the top
        val sw = fw * 0.14f; val sh = fh * 0.1f
        btns[L1].rect.set(fw * 0.04f, fh * 0.02f, fw * 0.04f + sw, fh * 0.02f + sh)
        btns[L2].rect.set(fw * 0.04f + sw + 10, fh * 0.02f, fw * 0.04f + 2 * sw + 10, fh * 0.02f + sh)
        btns[R1].rect.set(fw * 0.96f - sw, fh * 0.02f, fw * 0.96f, fh * 0.02f + sh)
        btns[R2].rect.set(fw * 0.96f - 2 * sw - 10, fh * 0.02f, fw * 0.96f - sw - 10, fh * 0.02f + sh)
        btns[SELECT].rect.set(fw * 0.40f - sw * 0.5f, fh * 0.46f, fw * 0.40f + sw * 0.5f, fh * 0.46f + sh)
        btns[START].rect.set(fw * 0.60f - sw * 0.5f, fh * 0.46f, fw * 0.60f + sw * 0.5f, fh * 0.46f + sh)
        text.textSize = fh * 0.06f
        lKnobX = lsx; lKnobY = lsy; rKnobX = rsx; rKnobY = rsy
    }
    private var rsr = 0f

    private fun place(b: Btn, x: Float, y: Float, r: Float) { b.cx = x; b.cy = y; b.r = r }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF1B1B1F.toInt())
        // sticks
        for ((x, y, r, kx, ky) in listOf(
            listOf(lsx, lsy, lsr, lKnobX, lKnobY), listOf(rsx, rsy, rsr, rKnobX, rKnobY))) {
            fill.color = 0xFF2C2C33.toInt(); c.drawCircle(x, y, r, fill); c.drawCircle(x, y, r, stroke)
            fill.color = 0xFF5A5A66.toInt(); c.drawCircle(kx, ky, r * 0.45f, fill)
        }
        // dpad
        val arm = dpr * 0.55f
        fill.color = 0xFF2C2C33.toInt()
        c.drawRoundRect(dpx - arm, dpy - dpr, dpx + arm, dpy + dpr, 12f, 12f, fill)
        c.drawRoundRect(dpx - dpr, dpy - arm, dpx + dpr, dpy + arm, 12f, 12f, fill)
        fill.color = 0xFFAAAAAA.toInt()
        val on = dirOn()
        for ((i, p) in listOf(0 to (0f to -1f), 2 to (1f to 0f), 4 to (0f to 1f), 6 to (-1f to 0f))) {
            val active = on.contains(i)
            fill.color = if (active) 0xFFFFFFFF.toInt() else 0xFF777780.toInt()
            c.drawCircle(dpx + p.first * dpr * 0.7f, dpy + p.second * dpr * 0.7f, dpr * 0.14f, fill)
        }
        // buttons
        for (b in btns) {
            val pressed = curButtons and (1 shl b.bit) != 0
            fill.color = if (pressed) 0xFF4C8DF6.toInt() else 0xFF3A3A44.toInt()
            if (b.round) {
                c.drawCircle(b.cx, b.cy, b.r, fill); c.drawCircle(b.cx, b.cy, b.r, stroke)
                c.drawText(b.label, b.cx, b.cy + text.textSize / 3, text)
            } else {
                c.drawRoundRect(b.rect, 16f, 16f, fill); c.drawRoundRect(b.rect, 16f, 16f, stroke)
                c.drawText(b.label, b.rect.centerX(), b.rect.centerY() + text.textSize / 3, text)
            }
        }
    }

    private fun dirOn(): Set<Int> = when (curHat) {
        0 -> setOf(0); 1 -> setOf(0, 2); 2 -> setOf(2); 3 -> setOf(2, 4)
        4 -> setOf(4); 5 -> setOf(4, 6); 6 -> setOf(6); 7 -> setOf(6, 0)
        else -> emptySet()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val action = e.actionMasked
        val idx = e.actionIndex
        val upIdx = if (action == MotionEvent.ACTION_POINTER_UP) idx else -1
        val allUp = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            val pid = e.getPointerId(idx); val x = e.getX(idx); val y = e.getY(idx)
            if (leftId == -1 && hypot(x - lsx, y - lsy) < lsr * 1.4f) leftId = pid
            else if (rightId == -1 && hypot(x - rsx, y - rsy) < rsr * 1.4f) rightId = pid
        }
        if (allUp) { leftId = -1; rightId = -1 }
        if (upIdx >= 0) {
            val pid = e.getPointerId(upIdx)
            if (pid == leftId) leftId = -1
            if (pid == rightId) rightId = -1
        }

        var buttons = 0; var hat = HAT_NONE
        lKnobX = lsx; lKnobY = lsy; rKnobX = rsx; rKnobY = rsy
        var lx = 128; var ly = 128; var rx = 128; var ry = 128

        if (!allUp) for (i in 0 until e.pointerCount) {
            if (i == upIdx) continue
            val pid = e.getPointerId(i); val x = e.getX(i); val y = e.getY(i)
            when (pid) {
                leftId -> { val s = stick(x, y, lsx, lsy, lsr); lKnobX = s[0]; lKnobY = s[1]; lx = s[2].toInt(); ly = s[3].toInt() }
                rightId -> { val s = stick(x, y, rsx, rsy, rsr); rKnobX = s[0]; rKnobY = s[1]; rx = s[2].toInt(); ry = s[3].toInt() }
                else -> {
                    for (b in btns) {
                        val hit = if (b.round) hypot(x - b.cx, y - b.cy) < b.r * 1.2f else b.rect.contains(x, y)
                        if (hit) buttons = buttons or (1 shl b.bit)
                    }
                    if (hypot(x - dpx, y - dpy) < dpr * 1.3f && hypot(x - dpx, y - dpy) > dpr * 0.15f) {
                        // angle: 0 = up, clockwise, in 45 degree sectors
                        var deg = Math.toDegrees(atan2((x - dpx).toDouble(), -(y - dpy).toDouble()))
                        if (deg < 0) deg += 360.0
                        hat = (((deg + 22.5) / 45.0).toInt()) % 8
                    }
                }
            }
        }

        curButtons = buttons; curHat = hat; curLx = lx; curLy = ly; curRx = rx; curRy = ry
        val state = listOf(buttons, lx, ly, rx, ry, hat)
        if (state != lastSent) { lastSent = state; onState(buttons, lx, ly, rx, ry, hat) }
        invalidate()
        return true
    }

    /** Returns [knobX, knobY, axisX(0..255), axisY(0..255)] */
    private fun stick(x: Float, y: Float, cx: Float, cy: Float, r: Float): FloatArray {
        var dx = x - cx; var dy = y - cy
        val d = hypot(dx, dy)
        if (d > r) { dx = dx / d * r; dy = dy / d * r }
        val ax = (128 + dx / r * 127).coerceIn(0f, 255f)
        val ay = (128 + dy / r * 127).coerceIn(0f, 255f)
        return floatArrayOf(cx + dx, cy + dy, ax, ay)
    }
}
